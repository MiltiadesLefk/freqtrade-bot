import logging
from datetime import datetime
import talib.abstract as ta
from pandas import DataFrame
from freqtrade.strategy import IStrategy, IntParameter, CategoricalParameter

logger = logging.getLogger(__name__)


class BTCTrendDaily(IStrategy):
    """
    BTC daily long-only trend following. No ML.

    Origin (2026-09-06): the 15m/1h FreqAI triple-barrier design failed 43
    straight tests. A timeframe sweep on identical rule families showed a clean
    monotonic gradient - OOS profit factor 0.70 at 1m, 0.83 at 5m, 0.90 at 15m
    (where the old bot lived), 0.97 at 1h, 1.08 at 1d - i.e. the edge was never
    absent, it was being eaten by turnover. This strategy sits at the slow end.

    Rule: long while close > SMA(n), flat otherwise. Long-only, unlevered.
    Anchored walk-forward (select n on the past, trade the next 90d, roll):
    PF 1.225, Sharpe 0.99, +52.6%, max DD 21.1%, vs buy&hold PF 1.070 / +22.5%
    / DD 53.0%. Every block selected n=50; PF>1.0 across n=20..200, so this is
    a plateau rather than a fitted point.

    Leverage stays 1x deliberately: the same system at 3x drew down 90.5%.
    """

    INTERFACE_VERSION = 3
    timeframe = "1d"
    can_short = False

    # Trend exit is the risk control. The stop is a disaster backstop only and
    # is set wide so it does not silently truncate the tested system.
    stoploss = -0.99
    trailing_stop = False
    minimal_roi = {"0": 99}

    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    startup_candle_count = 250

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    # Deliberately small space: daily bars yield only ~27 trades over 2 years,
    # so every extra dimension buys overfit rather than insight.
    sma_period = IntParameter(20, 200, default=50, space="buy", optimize=True)
    # Separate exit MA lets the system hold trends longer than it enters them.
    exit_sma_period = IntParameter(10, 120, default=50, space="sell", optimize=True)
    # Long-only was the best risk-adjusted variant in walk-forward; the
    # long/short variant earned more (+82.8%) at a worse Sharpe and deeper DD.
    allow_short = CategoricalParameter([True, False], default=False,
                                       space="buy", optimize=False)

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag, side: str, **kwargs) -> float:
        return 1.0

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        for p in set(list(self.sma_period.range) + list(self.exit_sma_period.range)):
            dataframe[f"sma_{p}"] = ta.SMA(dataframe, timeperiod=p)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        sma = dataframe[f"sma_{self.sma_period.value}"]
        dataframe.loc[
            (dataframe["close"] > sma) & (dataframe["volume"] > 0),
            ["enter_long", "enter_tag"],
        ] = (1, "above_sma")
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        sma = dataframe[f"sma_{self.exit_sma_period.value}"]
        dataframe.loc[dataframe["close"] < sma, ["exit_long", "exit_tag"]] = (1, "below_sma")
        return dataframe
