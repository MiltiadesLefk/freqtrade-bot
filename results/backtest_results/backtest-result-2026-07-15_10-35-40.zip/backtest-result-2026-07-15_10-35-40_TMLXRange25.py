import talib.abstract as ta
from pandas import DataFrame

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXRange25(TradingMLStrategyV2):
    """
    XC4: range-regime filter. Live evidence: the system prints money in calm
    ranges (Jul 8-14) and bleeds via stops when price trends (stops:TPs = 2:1
    full-span). Block entries while 15m ADX(14) says the market is trending.
    Post-freqai indicator only — prediction cache stays valid.
    """

    ADX_MAX = 25

    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        dataframe = super().populate_indicators(dataframe, metadata)
        dataframe["adx_gate"] = ta.ADX(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        dataframe = super().populate_entry_trend(dataframe, metadata)
        hot = dataframe["adx_gate"] >= self.ADX_MAX
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe.loc[hot, col] = 0
        return dataframe
