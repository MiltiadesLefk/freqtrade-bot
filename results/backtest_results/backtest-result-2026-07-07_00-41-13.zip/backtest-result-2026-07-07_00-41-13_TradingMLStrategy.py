import logging
from typing import List, Optional, Union
import talib.abstract as ta
from pandas import DataFrame
from freqtrade.strategy import (
    IStrategy,
    DecimalParameter,
    CategoricalParameter,
    stoploss_from_open,
)
from freqtrade.persistence import Trade
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class TradingMLStrategy(IStrategy):
    """
    TradingMLStrategy — BTC-Only FreqAI LightGBM Regressor

    Trades BTC/USDT perpetual futures (long and short) on Binance.
    Predicts % price change 3 hours ahead (12 × 15m candles).
    Uses a two-mode exit system (all handled by custom_exit/custom_stoploss —
    config-level trailing is disabled):
      - Weak signal  → exits at dynamic TP or proportional loss floor
      - Strong signal → loss floor until half-TP, then a trailing stop
        (dynamic_tp / 3 behind best price) rides the trend

    Only 25% of wallet is deployed per trade (tradable_balance_ratio × stake_amount).
    This provides capital preservation without relying on tight artificial stoplosses.
    """

    # ── FreqAI config ────────────────────────────────────────────────────────
    freqai_info = {
        "feature_parameters": {
            "include_timeframes": ["15m", "1h"],
            "include_corr_pairlist": [],              # BTC-only — no altcoin noise
            "label_period_candles": 12,               # Predict 3h ahead on 15m
            "include_shifted_candles": 3,             # See last 3 candles of all features
            "indicator_periods_candles": [10, 20, 50],
        }
    }

    # ── Strategy flags ───────────────────────────────────────────────────────
    timeframe = "15m"
    can_short = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = True
    process_only_new_candles = True
    startup_candle_count = 700
    use_custom_stoploss = True

    # ── Orders ───────────────────────────────────────────────────────────────
    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True,
        "stoploss_on_exchange_interval": 60,
    }

    # ── Default risk settings (overridden by hyperopt results when applied) ──
    stoploss = -0.181
    # Config-level trailing is OFF: custom_stoploss owns all stop movement.
    # In freqtrade, use_custom_stoploss and trailing_stop BOTH run and the stop
    # only ever ratchets tighter — running the two systems in parallel meant
    # neither behaved as designed. All values here are in leveraged profit space
    # (5x leverage: 0.05 profit ≈ 1% price move).
    trailing_stop = False
    trailing_stop_positive = None
    trailing_stop_positive_offset = 0.0
    trailing_only_offset_is_reached = False

    # ROI is effectively disabled — custom stoploss and trailing stop handle exits
    minimal_roi = {"0": 99}

    # ── Hyperopt results (applied 2026-04-25) ────────────────────────────────
    # Epoch 490/500: 252 trades, 52.8% win rate, +93.58% over 7 months (Sep 2025 – Apr 2026)
    # ⚠ IN-SAMPLE number: best-of-500 epochs on the optimization window itself.
    #   Expect far less out of sample. Validate on data the optimizer never saw.
    # Loss function: SharpeHyperOptLoss | Timerange: 20250901-20260401
    # Features: relaxed filters, EMA 50 entry, market regime features, 60-day training, 1-day backtest retraining
    buy_params = {
        "entry_threshold": 0.006,
    }
    sell_params = {
        "exit_threshold":    0.013,
        "lock_hours":        3.0,
        "rr_ratio":          0.8,
        "tp_multiplier":     3.3,
        "weak_strong_cutoff": 0.08,
    }
    # ─────────────────────────────────────────────────────────────────────────

    # ── Hyperopt parameter definitions ───────────────────────────────────────
    # During dry run / live: .value always returns the default= value below.
    # Ranges are ONLY used during hyperopt runs.

    # Minimum predicted % move over 3h to open a trade
    entry_threshold = DecimalParameter(0.003, 0.025, default=0.010, decimals=3, space="buy",  optimize=True)

    # Predicted % flip needed to trigger exit signal (can differ from entry)
    exit_threshold  = DecimalParameter(0.002, 0.015, default=0.006, decimals=3, space="sell", optimize=True)

    # Dynamic TP formula: TP = abs(prediction) × tp_multiplier − 0.002
    tp_multiplier   = DecimalParameter(2.0, 8.0, default=5.0, decimals=1, space="sell", optimize=True)

    # TP below this → weak signal (exit at TP); above → strong signal (trailing stop)
    weak_strong_cutoff = DecimalParameter(0.02, 0.10, default=0.04, decimals=2, space="sell", optimize=True)

    # Loss floor multiplier: SL floor = dynamic_tp × rr_ratio
    rr_ratio = DecimalParameter(0.5, 2.5, default=1.0, decimals=1, space="sell", optimize=True)

    # Hours to lock BTC after a stoploss exit (prevents revenge trading)
    lock_hours = CategoricalParameter(
        [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0],
        default=1.0, space="sell", optimize=True
    )

    # ── Stoploss search space ─────────────────────────────────────────────────
    @staticmethod
    def stoploss_space() -> List:
        from freqtrade.optimize.space import SKDecimal
        return [SKDecimal(-0.25, -0.05, decimals=2, name="stoploss")]

    # NOTE: no trailing_space() — config-level trailing stays off; hyperopt
    # must not be run with --spaces trailing for this strategy.

    # ── Leverage ──────────────────────────────────────────────────────────────
    def leverage(self, pair: str, current_time, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag, side: str, **kwargs) -> float:
        return 5.0

    # ── Custom stoploss (two-mode exit logic) ─────────────────────────────────
    def custom_stoploss(self, pair: str, trade: Trade,
                        current_time: datetime, current_rate: float,
                        current_profit: float, after_fill: bool,
                        **kwargs) -> float:
        """
        Weak signal  (dynamic_tp < weak_strong_cutoff):
          → Exit at +dynamic_tp profit (clean TP via custom_exit)
          → Exit at -(dynamic_tp × rr_ratio) loss (proportional floor)
          → One loss can never cost more than rr_ratio times one winner

        Strong signal (dynamic_tp >= weak_strong_cutoff):
          → Same proportional floor until half the TP is reached,
          → then trail at dynamic_tp / 3 behind the best price
            (freqtrade only ever tightens the stop, so a constant
             distance from current_rate acts as a trailing stop)
        """
        cutoff     = self.weak_strong_cutoff.value
        multiplier = self.tp_multiplier.value
        rr         = self.rr_ratio.value

        try:
            prediction = float(trade.enter_tag)
        except (ValueError, TypeError):
            return None    # Keep previous stop (initial -0.181 backstop)

        dynamic_tp = abs(prediction) * multiplier - 0.002
        dynamic_tp = max(0.01, min(0.20, dynamic_tp))

        # Proportional loss floor, pinned relative to the open price.
        # stoploss_from_open returns 0.0 when price is already past the floor —
        # translate that to None so the previously placed stop order stands.
        floor = stoploss_from_open(
            -(dynamic_tp * rr), current_profit,
            is_short=trade.is_short, leverage=trade.leverage,
        )

        if dynamic_tp < cutoff or current_profit < dynamic_tp * 0.5:
            return floor or None

        # ── Strong signal past half-TP: trail behind the best price ─────
        return -(dynamic_tp / 3.0)

    # ── Custom exit (Take Profit logic) ───────────────────────────────────────
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[Union[str, bool]]:
        cutoff     = self.weak_strong_cutoff.value
        multiplier = self.tp_multiplier.value

        try:
            prediction = float(trade.enter_tag)
            dynamic_tp = abs(prediction) * multiplier - 0.002
            dynamic_tp = max(0.01, min(0.20, dynamic_tp))

            if dynamic_tp < cutoff:
                # ── Weak signal: Take Profit Target ──────────────────────
                if current_profit >= dynamic_tp:
                    return "dynamic_take_profit"   # Triggers clean exit and logs perfectly!

        except (ValueError, TypeError):
            pass

        return None

    # ── Feature engineering ───────────────────────────────────────────────────
    def feature_engineering_expand_all(self, dataframe: DataFrame,
                                        period: int, metadata: dict,
                                        **kwargs) -> DataFrame:
        # RSI
        dataframe[f"%-rsi-period_{period}"] = ta.RSI(dataframe, timeperiod=period)

        # Bollinger Bands
        bollinger = ta.BBANDS(dataframe, timeperiod=period)
        dataframe[f"%-bb_upperband-period_{period}"]  = bollinger["upperband"]
        dataframe[f"%-bb_middleband-period_{period}"] = bollinger["middleband"]
        dataframe[f"%-bb_lowerband-period_{period}"]  = bollinger["lowerband"]
        dataframe[f"%-bb_width-period_{period}"]      = (
            bollinger["upperband"] - bollinger["lowerband"]
        ) / bollinger["middleband"]
        dataframe[f"%-bb_pctb-period_{period}"]       = (
            (dataframe["close"] - bollinger["lowerband"]) /
            (bollinger["upperband"] - bollinger["lowerband"])
        )

        # ATR (volatility)
        dataframe[f"%-atr-period_{period}"] = ta.ATR(dataframe, timeperiod=period)

        # MFI (money flow)
        dataframe[f"%-mfi-period_{period}"] = ta.MFI(dataframe, timeperiod=period)

        # ROC (rate of change / momentum)
        dataframe[f"%-roc-period_{period}"] = ta.ROC(dataframe, timeperiod=period)

        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame,
                                          metadata: dict, **kwargs) -> DataFrame:
        # Trend strength
        dataframe["%-adx"] = ta.ADX(dataframe, timeperiod=14)

        # Volume
        dataframe["%-volume"]       = dataframe["volume"]
        dataframe["%-volume_mean"]  = dataframe["volume"].rolling(20).mean()
        dataframe["%-volume_ratio"] = (
            dataframe["volume"] / dataframe["volume"].rolling(20).mean()
        )

        # Price action
        dataframe["%-price_change"]   = dataframe["close"].pct_change()
        dataframe["%-high_low_range"] = (
            dataframe["high"] - dataframe["low"]
        ) / dataframe["close"]

        # MACD
        macd = ta.MACD(dataframe)
        dataframe["%-macd"]       = macd["macd"]
        dataframe["%-macdsignal"] = macd["macdsignal"]
        dataframe["%-macdhist"]   = macd["macdhist"]

        # Stochastic
        stoch = ta.STOCH(dataframe)
        dataframe["%-slowk"] = stoch["slowk"]
        dataframe["%-slowd"] = stoch["slowd"]

        # EMA levels
        dataframe["%-ema_10"]  = ta.EMA(dataframe, timeperiod=10)
        dataframe["%-ema_20"]  = ta.EMA(dataframe, timeperiod=20)
        dataframe["%-ema_50"]  = ta.EMA(dataframe, timeperiod=50)
        dataframe["%-ema_200"] = ta.EMA(dataframe, timeperiod=200)

        # EMA distances from price (normalised)
        dataframe["%-ema_10_dist"]  = (dataframe["close"] - dataframe["%-ema_10"])  / dataframe["close"]
        dataframe["%-ema_20_dist"]  = (dataframe["close"] - dataframe["%-ema_20"])  / dataframe["close"]
        dataframe["%-ema_50_dist"]  = (dataframe["close"] - dataframe["%-ema_50"])  / dataframe["close"]
        dataframe["%-ema_200_dist"] = (dataframe["close"] - dataframe["%-ema_200"]) / dataframe["close"]

        # ── Market regime features ────────────────────────────────────────────
        # These help the model self-identify bull/bear/choppy environments
        # without hard-coded directional filters that lag market reversals.

        # Short-term vs long-term trend alignment (positive = uptrend, negative = downtrend)
        dataframe["%-ema_10_50_ratio"]   = (dataframe["%-ema_10"]  - dataframe["%-ema_50"])  / dataframe["%-ema_50"]
        dataframe["%-ema_20_200_ratio"]  = (dataframe["%-ema_20"]  - dataframe["%-ema_200"]) / dataframe["%-ema_200"]
        dataframe["%-ema_50_200_ratio"]  = (dataframe["%-ema_50"]  - dataframe["%-ema_200"]) / dataframe["%-ema_200"]

        # Long-term Rate of Change — captures broad momentum over 48h, 96h, 1 week
        dataframe["%-roc_192"]  = ta.ROC(dataframe, timeperiod=192)   # 48 hours on 15m
        dataframe["%-roc_384"]  = ta.ROC(dataframe, timeperiod=384)   # 96 hours on 15m
        dataframe["%-roc_672"]  = ta.ROC(dataframe, timeperiod=672)   # 1 week on 15m

        # Momentum acceleration: is momentum speeding up or slowing down?
        dataframe["%-macd_momentum"] = dataframe["%-macdhist"] - dataframe["%-macdhist"].shift(4)

        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame,
                                      metadata: dict, **kwargs) -> DataFrame:
        # Time context
        dataframe["%-day_of_week"] = dataframe["date"].dt.dayofweek
        dataframe["%-hour_of_day"] = dataframe["date"].dt.hour

        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame,
                           metadata: dict, **kwargs) -> DataFrame:
        # Target: % price change over next 12 candles (3 hours on 15m)
        dataframe["&-price_change"] = (
            dataframe["close"].shift(
                -self.freqai_info["feature_parameters"]["label_period_candles"]
            ) - dataframe["close"]
        ) / dataframe["close"]
        return dataframe

    # ── Informative pairs (1h context for BTC) ────────────────────────────────
    def informative_pairs(self):
        return [("BTC/USDT:USDT", "1h")]

    # ── Indicators ────────────────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        # 1h context reaches the model via freqai include_timeframes — the
        # previous manual 1h merge here produced columns the model never saw.

        # Run FreqAI prediction
        dataframe = self.freqai.start(dataframe, metadata, self)

        # Filters computed after freqai.start() — used in entry signals
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)

        return dataframe

    # ── Entry signals ─────────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        entry = self.entry_threshold.value

        # --- Detailed Logging ---
        pred = dataframe["&-price_change"].iloc[-1]
        do_predict = dataframe["do_predict"].iloc[-1]
        adx = dataframe["adx"].iloc[-1]
        close = dataframe["close"].iloc[-1]

        di_ok = do_predict == 1
        adx_ok = adx > 15
        long_pred_ok = pred > entry
        short_pred_ok = pred < -entry

        if long_pred_ok and di_ok and adx_ok:
            decision = "🚀 TAKING LONG TRADE!"
        elif short_pred_ok and di_ok and adx_ok:
            decision = "🩸 TAKING SHORT TRADE!"
        else:
            blocks = []
            if not (long_pred_ok or short_pred_ok):
                blocks.append(f"Prediction ({pred:.4f}) too weak (needs > {entry} or < {-entry})")
            if not di_ok:
                blocks.append(f"FreqAI outlier (do_predict={do_predict})")
            if not adx_ok:
                blocks.append(f"ADX ({adx:.1f}) <= 15")

            decision = "SKIPPED: " + " | ".join(blocks)

        logger.info(
            f"🔎 {metadata['pair']} | Pred: {pred:.4f} | do_predict: {do_predict} | "
            f"ADX: {adx:.1f} | Close: {close:.1f} => {decision}"
        )
        # ------------------------

        # Long: model predicts BTC going up, prediction trusted by FreqAI
        # (do_predict == 1 → not a data outlier), ADX confirms a trend exists.
        # No EMA-side or volume-spike gates: the model's regime features carry
        # that context, and those gates blocked ~3 in 4 valid signals live.
        dataframe.loc[
            (dataframe["&-price_change"] > entry) &
            (dataframe["do_predict"] == 1) &
            (dataframe["volume"] > 0) &
            (dataframe["adx"] > 15),
            "enter_long"
        ] = 1

        dataframe.loc[
            dataframe["enter_long"] == 1,
            "enter_tag"
        ] = dataframe["&-price_change"].astype(str)

        # Short: mirror of the long conditions
        dataframe.loc[
            (dataframe["&-price_change"] < -entry) &
            (dataframe["do_predict"] == 1) &
            (dataframe["volume"] > 0) &
            (dataframe["adx"] > 15),
            "enter_short"
        ] = 1

        dataframe.loc[
            dataframe["enter_short"] == 1,
            "enter_tag"
        ] = dataframe["&-price_change"].astype(str)

        return dataframe

    # ── Exit signals ──────────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        ex = self.exit_threshold.value

        # Exit long when model strongly flips bearish
        dataframe.loc[
            (dataframe["&-price_change"] < -ex),
            "exit_long"
        ] = 1

        # Exit short when model strongly flips bullish
        dataframe.loc[
            (dataframe["&-price_change"] > ex),
            "exit_short"
        ] = 1

        return dataframe

    # ── Trade confirmation hooks ──────────────────────────────────────────────
    def confirm_trade_entry(self, pair: str, order_type: str,
                            amount: float, rate: float,
                            time_in_force: str, current_time: datetime,
                            entry_tag: str, side: str, **kwargs) -> bool:
        return True

    def confirm_trade_exit(self, pair: str, trade: Trade, order_type: str,
                           amount: float, rate: float, time_in_force: str,
                           exit_reason: str, current_time: datetime,
                           **kwargs) -> bool:
        """
        After a stoploss, lock BTC for lock_hours to prevent immediate re-entry
        into a continuing losing trend. lock_hours=0 disables this behaviour.

        Floor exits driven by custom_stoploss get labeled "trailing_stop_loss"
        by freqtrade (the stop had been moved after entry), so that label —
        and "liquidation" — must count as stoploss exits here too.
        """
        if exit_reason in (
            "stoploss", "stoploss_on_exchange", "trailing_stop_loss", "liquidation",
        ):
            hours = self.lock_hours.value
            if hours and hours > 0:
                self.lock_pair(
                    pair,
                    until=current_time + timedelta(hours=float(hours)),
                    reason=f"stoploss_cooldown_{hours}h",
                )
        return True