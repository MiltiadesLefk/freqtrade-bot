"""
Standalone (NO-ML) day-trading strategies — 2026-07-16.

The SMC concepts died as decorations on the ML model (see CLAUDE.md kill
list). This tests the OTHER interpretation: the concepts AS the signal —
classic intraday liquidity playbook, textbook parameters, deliberately
untuned (tuning a no-edge pattern is how false positives are made).

Shared plumbing: 3x isolated, 1%-of-equity risk at the structural stop,
2R take-profit, 24h time-out, enter_tag carries "sl|tp" fractions.
"""
from datetime import timedelta
from typing import List, Optional, Union

import numpy as np
import pandas as pd
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, stoploss_from_absolute


class PureBase(IStrategy):
    timeframe = "15m"
    can_short = True
    use_exit_signal = False
    process_only_new_candles = True
    startup_candle_count = 800
    use_custom_stoploss = True
    stoploss = -0.15
    trailing_stop = False
    minimal_roi = {"0": 99}
    order_types = {
        "entry": "market", "exit": "market", "stoploss": "market",
        "stoploss_on_exchange": True, "stoploss_on_exchange_interval": 60,
    }

    LEVERAGE = 3.0
    RISK_PCT = 0.010
    MAX_STAKE_EQUITY_FRAC = 0.50
    RR = 2.0                 # TP = 2R
    SL_MIN, SL_MAX = 0.0015, 0.03
    TIME_STOP_H = 24

    def leverage(self, pair, current_time, current_rate, proposed_leverage,
                 max_leverage, entry_tag, side, **kwargs) -> float:
        return self.LEVERAGE

    @staticmethod
    def _parse_tag(tag) -> tuple:
        try:
            sl_s, tp_s = str(tag).split("|")
            sl, tp = float(sl_s), float(tp_s)
            if 0 < sl < 0.2 and 0 < tp < 0.5:
                return sl, tp
        except (ValueError, AttributeError):
            pass
        return None, None

    def custom_stoploss(self, pair, trade: Trade, current_time, current_rate,
                        current_profit, after_fill, **kwargs) -> Optional[float]:
        sl, _ = self._parse_tag(trade.enter_tag)
        if sl is None:
            return None
        floor_price = trade.open_rate * ((1 + sl) if trade.is_short else (1 - sl))
        return stoploss_from_absolute(
            floor_price, current_rate,
            is_short=trade.is_short, leverage=trade.leverage) or None

    def custom_exit(self, pair, trade: Trade, current_time, current_rate,
                    current_profit, **kwargs) -> Optional[Union[str, bool]]:
        _, tp = self._parse_tag(trade.enter_tag)
        if tp is not None:
            if trade.is_short:
                if current_rate <= trade.open_rate * (1 - tp):
                    return "tp_2r"
            elif current_rate >= trade.open_rate * (1 + tp):
                return "tp_2r"
        if (current_time - trade.open_date_utc) >= timedelta(hours=self.TIME_STOP_H):
            return "time_stop"
        return None

    def custom_stake_amount(self, pair, current_time, current_rate,
                            proposed_stake, min_stake, max_stake, leverage,
                            entry_tag, side, **kwargs) -> float:
        equity = self.wallets.get_total(self.config["stake_currency"])
        if equity <= 0:
            return proposed_stake
        sl, _ = self._parse_tag(entry_tag)
        if sl is None:
            return min(proposed_stake, equity * 0.25)
        stake = (equity * self.RISK_PCT) / (sl * leverage)
        stake = min(stake, equity * self.MAX_STAKE_EQUITY_FRAC, max_stake)
        if min_stake:
            stake = max(stake, min_stake)
        return stake

    # shared structure indicators
    def populate_indicators(self, df: DataFrame, metadata: dict) -> DataFrame:
        day = df["date"].dt.floor("D")
        dmax = df.groupby(day)["high"].max()
        dmin = df.groupby(day)["low"].min()
        df["pdh"] = day.map(dmax.shift(1))
        df["pdl"] = day.map(dmin.shift(1))
        return df

    def _apply(self, df, long_sig, long_sl_price, short_sig, short_sl_price):
        c = df["close"]
        sl_l = ((c - long_sl_price) / c).clip(lower=0)
        sl_s = ((short_sl_price - c) / c).clip(lower=0)
        ok_l = long_sig & sl_l.between(self.SL_MIN, self.SL_MAX)
        ok_s = short_sig & sl_s.between(self.SL_MIN, self.SL_MAX)
        df.loc[ok_l, "enter_long"] = 1
        df.loc[ok_l, "enter_tag"] = (
            sl_l.round(5).astype(str) + "|" + (sl_l * self.RR).round(5).astype(str))
        df.loc[ok_s, "enter_short"] = 1
        df.loc[ok_s, "enter_tag"] = (
            sl_s.round(5).astype(str) + "|" + (sl_s * self.RR).round(5).astype(str))
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        return df


class PureSweep(PureBase):
    """N1: previous-day low/high liquidity grab + reclaim, stop beyond the
    sweep wick, TP 2R."""

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        long_sig = (df["low"] < df["pdl"]) & (df["close"] > df["pdl"])
        short_sig = (df["high"] > df["pdh"]) & (df["close"] < df["pdh"])
        return self._apply(df, long_sig, df["low"] * 0.999,
                           short_sig, df["high"] * 1.001)


class PureFvg(PureBase):
    """N2: FVG retest — impulse leaves a gap, price returns into it and
    holds; stop beyond the far side of the gap, TP 2R."""

    GAP_MAX_AGE = 32  # candles

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        low, high, close = df["low"], df["high"], df["close"]
        bull = low > high.shift(2)
        bear = high < low.shift(2)
        bull_top = low.where(bull).ffill()
        bull_bot = high.shift(2).where(bull).ffill()
        bear_bot = high.where(bear).ffill()
        bear_top = low.shift(2).where(bear).ffill()
        idx = pd.Series(np.arange(len(df)), index=df.index)
        bull_age = idx - idx.where(bull).ffill()
        bear_age = idx - idx.where(bear).ffill()
        long_sig = (low <= bull_top) & (close > bull_top) & (bear_age.notna()) \
            & (bull_age <= self.GAP_MAX_AGE)
        short_sig = (high >= bear_bot) & (close < bear_bot) \
            & (bear_age <= self.GAP_MAX_AGE)
        return self._apply(df, long_sig, bull_bot * 0.999,
                           short_sig, bear_top * 1.001)


class PureBos(PureBase):
    """N3: break of structure + pullback to the broken level, stop below
    the level, TP 2R."""

    STRUCT = 96
    PB_MAX_AGE = 64

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        high, low, close = df["high"], df["low"], df["close"]
        prior_high = high.rolling(self.STRUCT).max().shift(1)
        prior_low = low.rolling(self.STRUCT).min().shift(1)
        bos_up = close > prior_high
        bos_dn = close < prior_low
        lvl_up = prior_high.where(bos_up).ffill()
        lvl_dn = prior_low.where(bos_dn).ffill()
        idx = pd.Series(np.arange(len(df)), index=df.index)
        age_up = idx - idx.where(bos_up).ffill()
        age_dn = idx - idx.where(bos_dn).ffill()
        long_sig = (low <= lvl_up) & (close > lvl_up) & (age_up <= self.PB_MAX_AGE) & (age_up > 0)
        short_sig = (high >= lvl_dn) & (close < lvl_dn) & (age_dn <= self.PB_MAX_AGE) & (age_dn > 0)
        return self._apply(df, long_sig, lvl_up * 0.996,
                           short_sig, lvl_dn * 1.004)
