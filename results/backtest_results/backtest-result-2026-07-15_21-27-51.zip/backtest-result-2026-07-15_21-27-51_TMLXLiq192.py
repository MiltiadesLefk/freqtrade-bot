from TMLXLiq import TMLXLiq


class TMLXLiq192(TMLXLiq):
    """XL2: liquidity pools from the last 48h instead of 24h."""

    LIQ_LOOKBACK = 192
