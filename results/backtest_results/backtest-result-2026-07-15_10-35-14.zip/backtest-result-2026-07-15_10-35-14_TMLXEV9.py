from TMLXEV6 import TMLXEV6


class TMLXEV9(TMLXEV6):
    """XC2: stricter EV fee gate — 3x round-trip fees."""

    EV_MIN = 0.009
