from pandas import DataFrame

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXShort(TradingMLStrategyV2):
    """X9S research variant: short-only (reuses bt_v3 prediction cache)."""

    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        dataframe = super().populate_entry_trend(dataframe, metadata)
        dataframe["enter_long"] = 0
        return dataframe
