from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXLong(TradingMLStrategyV2):
    """X9L research variant: long-only (reuses bt_v3 prediction cache)."""

    can_short = False
