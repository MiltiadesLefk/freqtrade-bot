import logging
from typing import List, Optional, Union
import talib.abstract as ta
from pandas import DataFrame
from freqtrade.strategy import IStrategy, DecimalParameter, CategoricalParameter
from freqtrade.persistence import Trade
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class TradingMLStrategyOld(IStrategy):
    """
    TradingMLStrategyOld (pre-audit snapshot) — BTC-Only FreqAI LightGBM Regressor

    Trades BTC/USDT perpetual futures (long and short) on Binance.
    Predicts % price change 3 hours ahead (12 × 15m candles).
    Uses a two-mode exit system:
      - Weak signal  → exits at dynamic TP or proportional loss floor
      - Strong signal → trailing stop rides the trend

    Only 25% of wallet is deployed per trade (tradable_balance_ratio × stake_amount).
    This provides capital preservation without relying on tight artificial stoplosses.
    """

    # ── FreqAI config ────────────────────────────────────────────────────────
    freqai_info = {
        "feature_parameters": {
            "include_timeframes": ["15m", "1h"],
            "include_corr_pairlist": [],              # BTC-only — no altcoin noise
            "label_period_candles": 12,               # Predict 3h ahead on 15m
            "include_shifted_candles": 3,             # See last 3 candles of all features
            "indicator_periods_candles": [10, 20, 50],
        }
    }

    # ── Strategy flags ───────────────────────────────────────────────────────
    timeframe = "15m"
    can_short = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = True
    process_only_new_candles = True
    startup_candle_count = 700
    use_custom_stoploss = True

    # ── Orders ───────────────────────────────────────────────────────────────
    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True,
        "stoploss_on_exchange_interval": 60,
    }

    # ── Default risk settings (overridden by hyperopt results when applied) ──
    stoploss = -0.181
    trailing_stop = True
    trailing_stop_positive = 0.143
    trailing_stop_positive_offset = 0.174
    trailing_only_offset_is_reached = False

    # ROI is effectively disabled — custom stoploss and trailing stop handle exits
    minimal_roi = {"0": 99}

    # ── Hyperopt results (applied 2026-04-25) ────────────────────────────────
    # Epoch 490/500: 252 trades, 52.8% win rate, +93.58% over 7 months (Sep 2025 – Apr 2026)
    # Loss function: SharpeHyperOptLoss | Timerange: 20250901-20260401
    # Features: relaxed filters, EMA 50 entry, market regime features, 60-day training, 1-day backtest retraining
    buy_params = {
        "entry_threshold": 0.006,
    }
    sell_params = {
        "exit_threshold":    0.013,
        "lock_hours":        3.0,
        "rr_ratio":          0.8,
        "tp_multiplier":     3.3,
        "weak_strong_cutoff": 0.08,
    }
    # ─────────────────────────────────────────────────────────────────────────

    # ── Hyperopt parameter definitions ───────────────────────────────────────
    # During dry run / live: .value always returns the default= value below.
    # Ranges are ONLY used during hyperopt runs.

    # Minimum predicted % move over 3h to open a trade
    entry_threshold = DecimalParameter(0.003, 0.025, default=0.010, decimals=3, space="buy",  optimize=True)

    # Predicted % flip needed to trigger exit signal (can differ from entry)
    exit_threshold  = DecimalParameter(0.002, 0.015, default=0.006, decimals=3, space="sell", optimize=True)

    # Dynamic TP formula: TP = abs(prediction) × tp_multiplier − 0.002
    tp_multiplier   = DecimalParameter(2.0, 8.0, default=5.0, decimals=1, space="sell", optimize=True)

    # TP below this → weak signal (exit at TP); above → strong signal (trailing stop)
    weak_strong_cutoff = DecimalParameter(0.02, 0.10, default=0.04, decimals=2, space="sell", optimize=True)

    # Loss floor multiplier: SL floor = dynamic_tp × rr_ratio
    rr_ratio = DecimalParameter(0.5, 2.5, default=1.0, decimals=1, space="sell", optimize=True)

    # Hours to lock BTC after a stoploss exit (prevents revenge trading)
    lock_hours = CategoricalParameter(
        [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0],
        default=1.0, space="sell", optimize=True
    )

    # ── Stoploss search space ─────────────────────────────────────────────────
    @staticmethod
    def stoploss_space() -> List:
        from freqtrade.optimize.space import SKDecimal
        return [SKDecimal(-0.25, -0.05, decimals=2, name="stoploss")]

    # ── Trailing stop search space ────────────────────────────────────────────
    @staticmethod
    def trailing_space() -> List:
        from freqtrade.optimize.space import SKDecimal, Categorical
        return [
            Categorical([True], name="trailing_stop"),
            SKDecimal(0.01, 0.05, decimals=3, name="trailing_stop_positive"),
            SKDecimal(0.01, 0.07, decimals=3, name="trailing_stop_positive_offset_p1"),
            Categorical([True], name="trailing_only_offset_is_reached"),
        ]

    # ── Leverage ──────────────────────────────────────────────────────────────
    def leverage(self, pair: str, current_time, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag, side: str, **kwargs) -> float:
        return 5.0

    # ── Custom stoploss (two-mode exit logic) ─────────────────────────────────
    def custom_stoploss(self, pair: str, trade: Trade,
                        current_time: datetime, current_rate: float,
                        current_profit: float, after_fill: bool,
                        **kwargs) -> float:
        """
        Weak signal  (dynamic_tp < weak_strong_cutoff):
          → Exit at +dynamic_tp profit (clean TP)
          → Exit at -(dynamic_tp × rr_ratio) loss (proportional floor)
          → One loss can never cost more than rr_ratio times one winner

        Strong signal (dynamic_tp >= weak_strong_cutoff):
          → Do not interfere — trailing stop rides the trend
          → Hard stoploss remains as absolute backstop
        """
        cutoff     = self.weak_strong_cutoff.value
        multiplier = self.tp_multiplier.value
        rr         = self.rr_ratio.value

        try:
            prediction = float(trade.enter_tag)
            dynamic_tp = abs(prediction) * multiplier - 0.002
            dynamic_tp = max(0.01, min(0.20, dynamic_tp))

            if dynamic_tp < cutoff:
                # ── Weak signal: bounded SL band ──────────────────────
                
                # Use stoploss_from_open to place the EXACT static stoploss on the exchange
                # so it shows up on the dashboard and is physically placed on Binance
                from freqtrade.strategy import stoploss_from_open
                sl_limit = -(dynamic_tp * rr)
                return stoploss_from_open(sl_limit, current_profit, is_short=trade.is_short)

            # ── Strong signal: trailing stop takes over ───────────────────
            # Do not interfere — let the global 18% stoploss handle it
        except (ValueError, TypeError):
            pass

        return -0.181    # Default global stoploss backstop

    # ── Custom exit (Take Profit logic) ───────────────────────────────────────
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[Union[str, bool]]:
        cutoff     = self.weak_strong_cutoff.value
        multiplier = self.tp_multiplier.value

        try:
            prediction = float(trade.enter_tag)
            dynamic_tp = abs(prediction) * multiplier - 0.002
            dynamic_tp = max(0.01, min(0.20, dynamic_tp))

            if dynamic_tp < cutoff:
                # ── Weak signal: Take Profit Target ──────────────────────
                if current_profit >= dynamic_tp:
                    return "dynamic_take_profit"   # Triggers clean exit and logs perfectly!

        except (ValueError, TypeError):
            pass

        return None

    # ── Feature engineering ───────────────────────────────────────────────────
    def feature_engineering_expand_all(self, dataframe: DataFrame,
                                        period: int, metadata: dict,
                                        **kwargs) -> DataFrame:
        # RSI
        dataframe[f"%-rsi-period_{period}"] = ta.RSI(dataframe, timeperiod=period)

        # Bollinger Bands
        bollinger = ta.BBANDS(dataframe, timeperiod=period)
        dataframe[f"%-bb_upperband-period_{period}"]  = bollinger["upperband"]
        dataframe[f"%-bb_middleband-period_{period}"] = bollinger["middleband"]
        dataframe[f"%-bb_lowerband-period_{period}"]  = bollinger["lowerband"]
        dataframe[f"%-bb_width-period_{period}"]      = (
            bollinger["upperband"] - bollinger["lowerband"]
        ) / bollinger["middleband"]
        dataframe[f"%-bb_pctb-period_{period}"]       = (
            (dataframe["close"] - bollinger["lowerband"]) /
            (bollinger["upperband"] - bollinger["lowerband"])
        )

        # ATR (volatility)
        dataframe[f"%-atr-period_{period}"] = ta.ATR(dataframe, timeperiod=period)

        # MFI (money flow)
        dataframe[f"%-mfi-period_{period}"] = ta.MFI(dataframe, timeperiod=period)

        # ROC (rate of change / momentum)
        dataframe[f"%-roc-period_{period}"] = ta.ROC(dataframe, timeperiod=period)

        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame,
                                          metadata: dict, **kwargs) -> DataFrame:
        # Trend strength
        dataframe["%-adx"] = ta.ADX(dataframe, timeperiod=14)

        # Volume
        dataframe["%-volume"]       = dataframe["volume"]
        dataframe["%-volume_mean"]  = dataframe["volume"].rolling(20).mean()
        dataframe["%-volume_ratio"] = (
            dataframe["volume"] / dataframe["volume"].rolling(20).mean()
        )

        # Price action
        dataframe["%-price_change"]   = dataframe["close"].pct_change()
        dataframe["%-high_low_range"] = (
            dataframe["high"] - dataframe["low"]
        ) / dataframe["close"]

        # MACD
        macd = ta.MACD(dataframe)
        dataframe["%-macd"]       = macd["macd"]
        dataframe["%-macdsignal"] = macd["macdsignal"]
        dataframe["%-macdhist"]   = macd["macdhist"]

        # Stochastic
        stoch = ta.STOCH(dataframe)
        dataframe["%-slowk"] = stoch["slowk"]
        dataframe["%-slowd"] = stoch["slowd"]

        # EMA levels
        dataframe["%-ema_10"]  = ta.EMA(dataframe, timeperiod=10)
        dataframe["%-ema_20"]  = ta.EMA(dataframe, timeperiod=20)
        dataframe["%-ema_50"]  = ta.EMA(dataframe, timeperiod=50)
        dataframe["%-ema_200"] = ta.EMA(dataframe, timeperiod=200)

        # EMA distances from price (normalised)
        dataframe["%-ema_10_dist"]  = (dataframe["close"] - dataframe["%-ema_10"])  / dataframe["close"]
        dataframe["%-ema_20_dist"]  = (dataframe["close"] - dataframe["%-ema_20"])  / dataframe["close"]
        dataframe["%-ema_50_dist"]  = (dataframe["close"] - dataframe["%-ema_50"])  / dataframe["close"]
        dataframe["%-ema_200_dist"] = (dataframe["close"] - dataframe["%-ema_200"]) / dataframe["close"]

        # ── Market regime features ────────────────────────────────────────────
        # These help the model self-identify bull/bear/choppy environments
        # without hard-coded directional filters that lag market reversals.

        # Short-term vs long-term trend alignment (positive = uptrend, negative = downtrend)
        dataframe["%-ema_10_50_ratio"]   = (dataframe["%-ema_10"]  - dataframe["%-ema_50"])  / dataframe["%-ema_50"]
        dataframe["%-ema_20_200_ratio"]  = (dataframe["%-ema_20"]  - dataframe["%-ema_200"]) / dataframe["%-ema_200"]
        dataframe["%-ema_50_200_ratio"]  = (dataframe["%-ema_50"]  - dataframe["%-ema_200"]) / dataframe["%-ema_200"]

        # Long-term Rate of Change — captures broad momentum over 48h, 96h, 1 week
        dataframe["%-roc_192"]  = ta.ROC(dataframe, timeperiod=192)   # 48 hours on 15m
        dataframe["%-roc_384"]  = ta.ROC(dataframe, timeperiod=384)   # 96 hours on 15m
        dataframe["%-roc_672"]  = ta.ROC(dataframe, timeperiod=672)   # 1 week on 15m

        # Momentum acceleration: is momentum speeding up or slowing down?
        dataframe["%-macd_momentum"] = dataframe["%-macdhist"] - dataframe["%-macdhist"].shift(4)

        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame,
                                      metadata: dict, **kwargs) -> DataFrame:
        # Time context
        dataframe["%-day_of_week"] = dataframe["date"].dt.dayofweek
        dataframe["%-hour_of_day"] = dataframe["date"].dt.hour

        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame,
                           metadata: dict, **kwargs) -> DataFrame:
        # Target: % price change over next 12 candles (3 hours on 15m)
        dataframe["&-price_change"] = (
            dataframe["close"].shift(
                -self.freqai_info["feature_parameters"]["label_period_candles"]
            ) - dataframe["close"]
        ) / dataframe["close"]
        return dataframe

    # ── Informative pairs (1h context for BTC) ────────────────────────────────
    def informative_pairs(self):
        return [("BTC/USDT:USDT", "1h")]

    # ── Indicators ────────────────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        # Merge 1h data for additional macro context features (used by ML model, not hard filters)
        if self.dp:
            informative = self.dp.get_pair_dataframe(
                pair=metadata["pair"], timeframe="1h"
            )
            informative["rsi_1h"]   = ta.RSI(informative, timeperiod=14)
            informative["adx_1h"]   = ta.ADX(informative, timeperiod=14)
            informative["ema_50_1h"] = ta.EMA(informative, timeperiod=50)

            from freqtrade.strategy import merge_informative_pair
            dataframe = merge_informative_pair(
                dataframe, informative, self.timeframe, "1h", ffill=True
            )

        # Run FreqAI prediction
        dataframe = self.freqai.start(dataframe, metadata, self)

        # Filters computed after freqai.start() — used in entry signals
        dataframe["ema_50"]      = ta.EMA(dataframe, timeperiod=50)
        dataframe["adx"]         = ta.ADX(dataframe, timeperiod=14)
        dataframe["volume_mean"] = dataframe["volume"].rolling(20).mean()

        return dataframe

    # ── Entry signals ─────────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        entry = self.entry_threshold.value

        # --- Detailed Logging ---
        pred = dataframe["&-price_change"].iloc[-1]
        adx = dataframe["adx"].iloc[-1]
        vol = dataframe["volume"].iloc[-1]
        vol_mean = dataframe["volume_mean"].iloc[-1]
        close = dataframe["close"].iloc[-1]
        ema50 = dataframe["ema_50"].iloc[-1]

        vol_ok = vol > vol_mean * 1.2
        adx_ok = adx > 15
        
        long_pred_ok = pred > entry
        long_ema_ok = close > ema50
        
        short_pred_ok = pred < -entry
        short_ema_ok = close < ema50

        if long_pred_ok and vol_ok and long_ema_ok and adx_ok:
            decision = "🚀 TAKING LONG TRADE!"
        elif short_pred_ok and vol_ok and short_ema_ok and adx_ok:
            decision = "🩸 TAKING SHORT TRADE!"
        else:
            blocks = []
            if not (long_pred_ok or short_pred_ok):
                blocks.append(f"Prediction ({pred:.4f}) too weak (needs > {entry} or < {-entry})")
            if not adx_ok:
                blocks.append(f"ADX ({adx:.1f}) <= 15")
            if not vol_ok:
                blocks.append(f"Volume ({vol:.1f}) not > 1.2x average ({vol_mean:.1f})")
            if long_pred_ok and not long_ema_ok:
                blocks.append(f"Price ({close:.1f}) below EMA50 ({ema50:.1f})")
            if short_pred_ok and not short_ema_ok:
                blocks.append(f"Price ({close:.1f}) above EMA50 ({ema50:.1f})")
            
            decision = "SKIPPED: " + " | ".join(blocks)

        logger.info(
            f"🔎 {metadata['pair']} | Pred: {pred:.4f} | ADX: {adx:.1f} | "
            f"Vol: {vol:.0f}/{vol_mean:.0f} | Close: {close:.1f} | EMA50: {ema50:.1f} => {decision}"
        )
        # ------------------------

        # Long: model predicts BTC going up, ADX trending, volume above average
        # The ML model itself handles regime identification via the market regime features.
        # We keep a light 15m EMA 50 filter to avoid entering in extreme chop.
        dataframe.loc[
            (dataframe["&-price_change"] > entry) &
            (dataframe["volume"] > 0) &
            (dataframe["close"] > dataframe["ema_50"]) &
            (dataframe["adx"] > 15) &
            (dataframe["volume"] > dataframe["volume_mean"] * 1.2),
            "enter_long"
        ] = 1

        dataframe.loc[
            dataframe["enter_long"] == 1,
            "enter_tag"
        ] = dataframe["&-price_change"].astype(str)

        # Short: model predicts BTC going down, ADX trending, volume above average
        dataframe.loc[
            (dataframe["&-price_change"] < -entry) &
            (dataframe["volume"] > 0) &
            (dataframe["close"] < dataframe["ema_50"]) &
            (dataframe["adx"] > 15) &
            (dataframe["volume"] > dataframe["volume_mean"] * 1.2),
            "enter_short"
        ] = 1

        dataframe.loc[
            dataframe["enter_short"] == 1,
            "enter_tag"
        ] = dataframe["&-price_change"].astype(str)

        return dataframe

    # ── Exit signals ──────────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        ex = self.exit_threshold.value

        # Exit long when model strongly flips bearish
        dataframe.loc[
            (dataframe["&-price_change"] < -ex),
            "exit_long"
        ] = 1

        # Exit short when model strongly flips bullish
        dataframe.loc[
            (dataframe["&-price_change"] > ex),
            "exit_short"
        ] = 1

        return dataframe

    # ── Trade confirmation hooks ──────────────────────────────────────────────
    def confirm_trade_entry(self, pair: str, order_type: str,
                            amount: float, rate: float,
                            time_in_force: str, current_time: datetime,
                            entry_tag: str, side: str, **kwargs) -> bool:
        return True

    def confirm_trade_exit(self, pair: str, trade: Trade, order_type: str,
                           amount: float, rate: float, time_in_force: str,
                           exit_reason: str, current_time: datetime,
                           **kwargs) -> bool:
        """
        After a stoploss, lock BTC for lock_hours to prevent immediate re-entry
        into a continuing losing trend. lock_hours=0 disables this behaviour.
        """
        if exit_reason in ("stoploss", "stoploss_on_exchange"):
            hours = self.lock_hours.value
            if hours and hours > 0:
                self.lock_pair(
                    pair,
                    until=current_time + timedelta(hours=float(hours)),
                    reason=f"stoploss_cooldown_{hours}h",
                )
        return True