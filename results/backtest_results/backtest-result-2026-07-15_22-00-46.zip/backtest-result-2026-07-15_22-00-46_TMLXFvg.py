"""
SMC/liquidity research variants (2026-07-15) — all execution-layer only, so
they reuse the bt_v3 prediction cache. Shared indicators live in TMLXSmcBase;
each variant changes exactly one thing vs TradingMLStrategyV2 (config F).

Concepts under test (user request): FVG, iFVG, BOS (aligned + fade),
previous-day-high/low liquidity as TP target, PDH/PDL sweep-reversal entries.
"""
from datetime import timedelta
from typing import Optional, Union

import numpy as np
import pandas as pd
from pandas import DataFrame

from freqtrade.exchange import timeframe_to_minutes
from freqtrade.persistence import Trade

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXSmcBase(TradingMLStrategyV2):
    """Shared structure indicators. Not run directly."""

    FVG_WINDOW = 96      # look back 24h for imbalance zones
    ZONE_NEAR = 0.01     # "at the zone" = within 1% of price
    STRUCT_WINDOW = 96   # swing window for BOS detection

    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        df = super().populate_indicators(dataframe, metadata)
        low, high, close = df["low"], df["high"], df["close"]

        # Fair value gaps (3-candle imbalance), most relevant zone in window
        bull_gap_top = low.where(low > high.shift(2))
        bear_gap_bot = high.where(high < low.shift(2))
        df["fvg_bull_top"] = bull_gap_top.rolling(self.FVG_WINDOW, min_periods=1).max()
        df["fvg_bear_bot"] = bear_gap_bot.rolling(self.FVG_WINDOW, min_periods=1).min()

        # Break of structure: last break direction (+1 up / -1 down)
        prior_high = high.rolling(self.STRUCT_WINDOW).max().shift(1)
        prior_low = low.rolling(self.STRUCT_WINDOW).min().shift(1)
        bos = np.where(close > prior_high, 1.0,
                       np.where(close < prior_low, -1.0, np.nan))
        df["bos_dir"] = pd.Series(bos, index=df.index).ffill()

        # Previous UTC-day high/low (completed day only — no lookahead)
        day = df["date"].dt.floor("D")
        dmax = df.groupby(day)["high"].max()
        dmin = df.groupby(day)["low"].min()
        df["pdh"] = day.map(dmax.shift(1))
        df["pdl"] = day.map(dmin.shift(1))
        return df

    def _mask_entries(self, df: DataFrame, long_ok, short_ok) -> DataFrame:
        for col, ok in (("enter_long", long_ok), ("enter_short", short_ok)):
            if col in df.columns:
                df.loc[(df[col] == 1) & (~ok.fillna(False)), col] = 0
        return df


class TMLXFvg(TMLXSmcBase):
    """XS1: FVG confluence — long only on top of a recent bullish imbalance,
    short only under a recent bearish one."""

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        c = df["close"]
        long_ok = (c >= df["fvg_bull_top"]) & ((c - df["fvg_bull_top"]) / c < self.ZONE_NEAR)
        short_ok = (c <= df["fvg_bear_bot"]) & ((df["fvg_bear_bot"] - c) / c < self.ZONE_NEAR)
        return self._mask_entries(df, long_ok, short_ok)


class TMLXIfvg(TMLXSmcBase):
    """XS2: inversion FVG — long just above a RECLAIMED bearish gap (zone
    flipped to support), short just below a LOST bullish gap."""

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        c = df["close"]
        long_ok = (c > df["fvg_bear_bot"]) & ((c - df["fvg_bear_bot"]) / c < self.ZONE_NEAR)
        short_ok = (c < df["fvg_bull_top"]) & ((df["fvg_bull_top"] - c) / c < self.ZONE_NEAR)
        return self._mask_entries(df, long_ok, short_ok)


class TMLXBosAlign(TMLXSmcBase):
    """XS3a: trade WITH the last break of structure."""

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        return self._mask_entries(df, df["bos_dir"] == 1, df["bos_dir"] == -1)


class TMLXBosFade(TMLXSmcBase):
    """XS3b: fade the last break of structure (sweep-reversal bias)."""

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        return self._mask_entries(df, df["bos_dir"] == -1, df["bos_dir"] == 1)


class TMLXSweep(TMLXSmcBase):
    """XS4: liquidity-grab reversal — enter only within 2h of a PDL sweep+
    reclaim (longs) / PDH sweep+reject (shorts)."""

    SWEEP_RECENT = 8  # candles

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        swept_low = ((df["low"] < df["pdl"]) & (df["close"] > df["pdl"]))
        swept_high = ((df["high"] > df["pdh"]) & (df["close"] < df["pdh"]))
        long_ok = swept_low.rolling(self.SWEEP_RECENT, min_periods=1).max().astype(bool)
        short_ok = swept_high.rolling(self.SWEEP_RECENT, min_periods=1).max().astype(bool)
        return self._mask_entries(df, long_ok, short_ok)


class TMLXPdhTarget(TMLXSmcBase):
    """XS5: keep the ATR stop (the leg that works), but target the day-level
    liquidity draw: TP front-runs PDH (long) / PDL (short). Skip entries with
    no room (<0.3%) or absurd room (>5%). enter_tag = "b|tp_frac"."""

    TP_FRONT = 0.0005
    TP_MIN, TP_MAX = 0.003, 0.05

    @staticmethod
    def _parse_tag(tag) -> tuple:
        try:
            b_s, tp_s = str(tag).split("|")
            b, tp = float(b_s), float(tp_s)
            if 0 < b < 0.2 and 0 < tp < 0.5:
                return b, tp
        except (ValueError, AttributeError):
            pass
        return None, None

    @staticmethod
    def _barrier_from_tag(trade: Trade) -> Optional[float]:
        return TMLXPdhTarget._parse_tag(trade.enter_tag)[0]

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = super().populate_entry_trend(df, metadata)
        c = df["close"]
        tp_long = (df["pdh"] * (1 - self.TP_FRONT) - c) / c
        tp_short = (c - df["pdl"] * (1 + self.TP_FRONT)) / c
        for col, tp in (("enter_long", tp_long), ("enter_short", tp_short)):
            if col not in df.columns:
                continue
            sig = df[col] == 1
            ok = sig & tp.between(self.TP_MIN, self.TP_MAX)
            df.loc[sig, col] = 0
            df.loc[ok, col] = 1
            df.loc[ok, "enter_tag"] = (
                df["barrier_frac"].round(5).astype(str) + "|" + tp.round(5).astype(str)
            )
        return df

    def custom_exit(self, pair: str, trade: Trade, current_time,
                    current_rate: float, current_profit: float,
                    **kwargs) -> Optional[Union[str, bool]]:
        _, tp = self._parse_tag(trade.enter_tag)
        if tp is not None:
            if trade.is_short:
                if current_rate <= trade.open_rate * (1 - tp):
                    return "tp_liquidity"
            elif current_rate >= trade.open_rate * (1 + tp):
                return "tp_liquidity"
        max_minutes = self._label_candles() * timeframe_to_minutes(self.timeframe)
        if (current_time - trade.open_date_utc) >= timedelta(minutes=max_minutes):
            return "time_barrier"
        return None

    def custom_stake_amount(self, pair: str, current_time, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float],
                            max_stake: float, leverage: float,
                            entry_tag: Optional[str], side: str,
                            **kwargs) -> float:
        equity = self.wallets.get_total(self.config["stake_currency"])
        if equity <= 0:
            return proposed_stake
        b, _ = self._parse_tag(entry_tag)
        if b is None:
            return min(proposed_stake, equity * self.FALLBACK_STAKE_EQUITY_FRAC)
        stake = (equity * self.RISK_PCT) / (b * leverage)
        stake = min(stake, equity * self.MAX_STAKE_EQUITY_FRAC, max_stake)
        if min_stake:
            stake = max(stake, min_stake)
        return stake
