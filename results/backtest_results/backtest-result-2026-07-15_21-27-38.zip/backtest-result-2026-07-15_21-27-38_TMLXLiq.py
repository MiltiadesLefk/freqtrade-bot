from datetime import timedelta
from typing import Optional, Union

from pandas import DataFrame

from freqtrade.exchange import timeframe_to_minutes
from freqtrade.persistence import Trade

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXLiq(TradingMLStrategyV2):
    """
    XL1 research variant (2026-07-15): liquidity-structure SL/TP.

    Same model, same entries — but the bracket is placed on market structure
    instead of ATR symmetry: SL just BEYOND the swing low/high of the last
    LIQ_LOOKBACK candles (past the resting-stop pool, so the trade isn't the
    easy liquidity), TP just IN FRONT of the opposite pool (exit before the
    crowd's target). R:R becomes asymmetric per trade; sizing still risks 1%
    of equity at the actual SL distance. enter_tag carries "sl|tp" fractions.
    """

    LIQ_LOOKBACK = 96   # 24h of 15m candles — the liquidity pool window
    SL_BUFFER = 0.001   # stop 0.1% beyond the swing point
    TP_FRONT = 0.0005   # TP 0.05% before the opposite pool
    MIN_DIST = 0.002    # both legs at least 0.2% away
    MAX_SL = 0.045      # keep the 3x floor inside the -0.15 backstop

    # ── tag helpers ───────────────────────────────────────────────────────────
    @staticmethod
    def _parse_tag(tag) -> tuple:
        try:
            sl_s, tp_s = str(tag).split("|")
            sl, tp = float(sl_s), float(tp_s)
            if 0 < sl < 0.2 and 0 < tp < 0.5:
                return sl, tp
        except (ValueError, AttributeError):
            pass
        return None, None

    @staticmethod
    def _barrier_from_tag(trade: Trade) -> Optional[float]:
        # inherited custom_stoploss pins the floor at open×(1∓sl)
        return TMLXLiq._parse_tag(trade.enter_tag)[0]

    # ── entries: attach structural levels, drop no-room signals ──────────────
    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        dataframe = super().populate_indicators(dataframe, metadata)
        dataframe["liq_low"] = dataframe["low"].rolling(self.LIQ_LOOKBACK).min()
        dataframe["liq_high"] = dataframe["high"].rolling(self.LIQ_LOOKBACK).max()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        dataframe = super().populate_entry_trend(dataframe, metadata)
        c = dataframe["close"]
        legs = {
            "enter_long": (
                (c - dataframe["liq_low"] * (1 - self.SL_BUFFER)) / c,
                (dataframe["liq_high"] * (1 - self.TP_FRONT) - c) / c,
            ),
            "enter_short": (
                (dataframe["liq_high"] * (1 + self.SL_BUFFER) - c) / c,
                (c - dataframe["liq_low"] * (1 + self.TP_FRONT)) / c,
            ),
        }
        for col, (sl, tp) in legs.items():
            if col not in dataframe.columns:
                continue
            sig = dataframe[col] == 1
            ok = sig & sl.between(self.MIN_DIST, self.MAX_SL) & (tp >= self.MIN_DIST)
            dataframe.loc[sig, col] = 0
            dataframe.loc[ok, col] = 1
            dataframe.loc[ok, "enter_tag"] = (
                sl.round(5).astype(str) + "|" + tp.round(5).astype(str)
            )
        return dataframe

    # ── exits: structural TP + inherited time/flip exits ──────────────────────
    def custom_exit(self, pair: str, trade: Trade, current_time,
                    current_rate: float, current_profit: float,
                    **kwargs) -> Optional[Union[str, bool]]:
        _, tp = self._parse_tag(trade.enter_tag)
        if tp is not None:
            if trade.is_short:
                if current_rate <= trade.open_rate * (1 - tp):
                    return "tp_liquidity"
            elif current_rate >= trade.open_rate * (1 + tp):
                return "tp_liquidity"

        max_minutes = self._label_candles() * timeframe_to_minutes(self.timeframe)
        if (current_time - trade.open_date_utc) >= timedelta(minutes=max_minutes):
            return "time_barrier"
        return None

    # ── sizing: 1% of equity at the STRUCTURAL stop distance ─────────────────
    def custom_stake_amount(self, pair: str, current_time, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float],
                            max_stake: float, leverage: float,
                            entry_tag: Optional[str], side: str,
                            **kwargs) -> float:
        equity = self.wallets.get_total(self.config["stake_currency"])
        if equity <= 0:
            return proposed_stake
        sl, _ = self._parse_tag(entry_tag)
        if sl is None:
            return min(proposed_stake, equity * self.FALLBACK_STAKE_EQUITY_FRAC)
        stake = (equity * self.RISK_PCT) / (sl * leverage)
        stake = min(stake, equity * self.MAX_STAKE_EQUITY_FRAC, max_stake)
        if min_stake:
            stake = max(stake, min_stake)
        return stake
