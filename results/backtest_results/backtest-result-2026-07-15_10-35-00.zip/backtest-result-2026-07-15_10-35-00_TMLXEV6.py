from pandas import DataFrame

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXEV6(TradingMLStrategyV2):
    """
    XC1: expected-value fee gate. The fee thesis says thin barriers can't pay
    the round trip; instead of a fixed prob margin, require the model's edge
    TIMES the leveraged barrier payoff to clear a fee multiple:
        (p_dir − p_opp) × b × leverage > EV_MIN  (0.006 = 2x round-trip fees)
    Run with margin loosened to 0.10 so the EV gate does the selecting.
    """

    EV_MIN = 0.006

    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        dataframe = super().populate_entry_trend(dataframe, metadata)
        payoff = dataframe["barrier_frac"] * self.LEVERAGE
        if "enter_long" in dataframe.columns:
            ev = (dataframe["tb_up"] - dataframe["tb_down"]) * payoff
            dataframe.loc[(dataframe["enter_long"] == 1) & (ev < self.EV_MIN),
                          "enter_long"] = 0
        if "enter_short" in dataframe.columns:
            ev = (dataframe["tb_down"] - dataframe["tb_up"]) * payoff
            dataframe.loc[(dataframe["enter_short"] == 1) & (ev < self.EV_MIN),
                          "enter_short"] = 0
        return dataframe
