import logging

import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from TradingMLStrategyV2 import TradingMLStrategyV2

logger = logging.getLogger(__name__)


class TMLX4h(TradingMLStrategyV2):
    """
    X2 research variant (2026-07-14, v2): lean hand-rolled 4h context features.

    The obvious route (include_timeframes + 4h) is impossible on a 15m base:
    the 4h EMA200 needs startup 3300 > freqtrade's hard cap of 5x the exchange
    candle limit (2495). So instead: four hand-picked 4h features whose warmup
    (<= 24 4h-candles = 384 base candles) fits the existing startup 800.
    4h rows are shifted +4h before the backward merge — they're dated by open
    time and only known at close.
    """

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return (
            [(p, "1h", "funding_rate") for p in pairs]
            + [(p, "4h") for p in pairs]
        )

    def feature_engineering_standard(self, dataframe: DataFrame,
                                     metadata: dict, **kwargs) -> DataFrame:
        dataframe = super().feature_engineering_standard(dataframe, metadata, **kwargs)

        cols = ["%-rsi_4h", "%-ema24_dist_4h", "%-roc_24h_4h", "%-atr_pct_4h"]
        h4 = None
        try:
            h4 = self.dp.get_pair_dataframe(metadata["pair"], "4h")
        except Exception as e:
            logger.warning(f"4h fetch failed for {metadata['pair']}: {e}")
        if h4 is not None and not h4.empty:
            h4 = h4.copy().sort_values("date")
            h4["%-rsi_4h"] = ta.RSI(h4, timeperiod=14)
            ema24 = ta.EMA(h4, timeperiod=24)
            h4["%-ema24_dist_4h"] = (h4["close"] - ema24) / h4["close"]
            h4["%-roc_24h_4h"] = ta.ROC(h4, timeperiod=6)
            h4["%-atr_pct_4h"] = ta.ATR(h4, timeperiod=24) / h4["close"]
            h4["date"] = h4["date"] + pd.Timedelta(hours=4)  # only closed candles
            dataframe = pd.merge_asof(
                dataframe, h4[["date"] + cols], on="date", direction="backward"
            )
        else:
            logger.warning(f"No 4h data for {metadata['pair']} — features stay NaN")
            for c in cols:
                dataframe[c] = float("nan")
        return dataframe
