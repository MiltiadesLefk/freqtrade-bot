from datetime import timedelta
from typing import Optional, Union

from freqtrade.exchange import timeframe_to_minutes
from freqtrade.persistence import Trade

from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXTP60(TradingMLStrategyV2):
    """
    XC3: partial take-profit at 60% of the barrier, stop unchanged at −b.
    The full-span decomposition showed early exits (model flips) are the only
    profitable component while full-barrier stops bleed — this tests whether
    systematically banking profit before the full barrier beats riding to it,
    at the cost of a designed 0.6:1 R:R.
    """

    TP_FRAC = 0.6

    def custom_exit(self, pair: str, trade: Trade, current_time,
                    current_rate: float, current_profit: float,
                    **kwargs) -> Optional[Union[str, bool]]:
        b = self._barrier_from_tag(trade)
        if b is not None:
            tp = b * self.TP_FRAC
            if trade.is_short:
                if current_rate <= trade.open_rate * (1 - tp):
                    return "tp_barrier"
            elif current_rate >= trade.open_rate * (1 + tp):
                return "tp_barrier"

        max_minutes = self._label_candles() * timeframe_to_minutes(self.timeframe)
        if (current_time - trade.open_date_utc) >= timedelta(minutes=max_minutes):
            return "time_barrier"
        return None
