import logging
from typing import List, Optional, Union
from datetime import datetime, timedelta

import numpy as np
import talib.abstract as ta
from pandas import DataFrame
from freqtrade.strategy import (
    IStrategy,
    DecimalParameter,
    CategoricalParameter,
    stoploss_from_open,
)
from freqtrade.exchange import timeframe_to_minutes
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)


class TradingMLStrategyV2(IStrategy):
    """
    TradingMLStrategyV2 — BTC-Only FreqAI Triple-Barrier Classifier

    Redesign after the 2026-07-06 audit showed the 3h-return regressor had no
    directional edge (win rate flat ~28% across prediction strength).

    Approach (López de Prado triple-barrier):
      - Label each 15m candle by which barrier price touches FIRST within the
        next 48 candles (12h): +4×ATR(96) → "tb_up", −4×ATR(96) → "tb_down",
        neither → "tb_flat".  Class balance on 2025-07→2026-07 data:
        ~31% / 34% / 34% — near-balanced, vol-adaptive, drift-resistant.
      - LightGBMClassifier outputs P(tb_up), P(tb_down), P(tb_flat) columns.
      - Enter when the directional probability clears prob_threshold AND beats
        the opposite class by prob_margin, with do_predict == 1.
      - Execution mirrors the label exactly: TP at +barrier, floor at −barrier,
        time-exit at 12h. What the model predicts is what the trade does.

    Run with:  --freqaimodel LightGBMClassifier
    Leverage 3x (down from 5x). All custom_* profit values are in leveraged
    profit space; barrier fractions stored in enter_tag are in PRICE space.
    """

    # Barrier width in ATR(96) multiples — must match the label definition.
    BARRIER_K = 4.0
    ATR_PERIOD = 96  # 24h of 15m candles

    # ── Strategy flags ───────────────────────────────────────────────────────
    timeframe = "15m"
    can_short = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = True
    process_only_new_candles = True
    startup_candle_count = 760  # ROC-672 + shifts headroom
    use_custom_stoploss = True

    # ── Orders ───────────────────────────────────────────────────────────────
    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True,
        "stoploss_on_exchange_interval": 60,
    }

    # ── Risk defaults ─────────────────────────────────────────────────────────
    # Backstop only (leveraged profit space: -0.15 ≈ -5% price at 3x).
    # The real stop is the per-trade barrier floor in custom_stoploss.
    stoploss = -0.15
    trailing_stop = False
    minimal_roi = {"0": 99}

    # ── Tunables ──────────────────────────────────────────────────────────────
    # Minimum probability of the directional class to enter
    prob_threshold = DecimalParameter(0.35, 0.60, default=0.45, decimals=2, space="buy", optimize=True)
    # Directional probability must beat the opposite class by this much
    prob_margin = DecimalParameter(0.00, 0.30, default=0.10, decimals=2, space="buy", optimize=True)
    # Opposite-class probability needed to force an early exit — deliberately
    # higher than the entry bar; otherwise the model churns out of trades
    # before either barrier is reached and fees eat the account.
    exit_prob_threshold = DecimalParameter(0.45, 0.80, default=0.60, decimals=2, space="sell", optimize=True)
    # Volatility circuit breaker: no NEW entries while ATR(96) exceeds this
    # multiple of its own 7-day median. The model's probabilities are
    # calibrated on the trailing 90d regime; when vol doubles overnight
    # (Feb 2026: 69% ann. vol vs 40% trained) it gets steamrolled.
    vol_regime_max = DecimalParameter(1.10, 3.00, default=1.50, decimals=2, space="buy", optimize=True)
    # Hours to pause after ANY exit (not just losses) — throttles fee churn.
    reentry_cooldown_hours = CategoricalParameter(
        [0, 0.5, 1.0, 2.0, 3.0, 4.0], default=2.0, space="sell", optimize=True
    )
    # Hours to lock the pair after a stoploss/floor exit
    lock_hours = CategoricalParameter(
        [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0],
        default=3.0, space="sell", optimize=True,
    )

    @staticmethod
    def stoploss_space() -> List:
        from freqtrade.optimize.space import SKDecimal
        return [SKDecimal(-0.25, -0.08, decimals=2, name="stoploss")]

    # ── Leverage ──────────────────────────────────────────────────────────────
    def leverage(self, pair: str, current_time, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag, side: str, **kwargs) -> float:
        return 3.0

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _label_candles(self) -> int:
        return int(self.freqai_info["feature_parameters"]["label_period_candles"])

    @staticmethod
    def _barrier_from_tag(trade: Trade) -> Optional[float]:
        """Barrier fraction (price space) stored in enter_tag at signal time."""
        try:
            b = float(trade.enter_tag)
            return b if 0 < b < 0.2 else None
        except (ValueError, TypeError):
            return None

    # ── Custom stoploss: barrier floor pinned to open ─────────────────────────
    def custom_stoploss(self, pair: str, trade: Trade,
                        current_time: datetime, current_rate: float,
                        current_profit: float, after_fill: bool,
                        **kwargs) -> Optional[float]:
        b = self._barrier_from_tag(trade)
        if b is None:
            return None  # keep backstop
        floor = stoploss_from_open(
            -(b * trade.leverage), current_profit,
            is_short=trade.is_short, leverage=trade.leverage,
        )
        return floor or None

    # ── Custom exit: TP barrier + time barrier ────────────────────────────────
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime,
                    current_rate: float, current_profit: float,
                    **kwargs) -> Optional[Union[str, bool]]:
        b = self._barrier_from_tag(trade)
        if b is not None and current_profit >= b * trade.leverage:
            return "tp_barrier"

        max_minutes = self._label_candles() * timeframe_to_minutes(self.timeframe)
        if (current_time - trade.open_date_utc) >= timedelta(minutes=max_minutes):
            return "time_barrier"
        return None

    # ── Feature engineering (lean + stationary) ───────────────────────────────
    def feature_engineering_expand_all(self, dataframe: DataFrame,
                                       period: int, metadata: dict,
                                       **kwargs) -> DataFrame:
        dataframe[f"%-rsi-period_{period}"] = ta.RSI(dataframe, timeperiod=period)

        bollinger = ta.BBANDS(dataframe, timeperiod=period)
        dataframe[f"%-bb_width-period_{period}"] = (
            bollinger["upperband"] - bollinger["lowerband"]
        ) / bollinger["middleband"]
        dataframe[f"%-bb_pctb-period_{period}"] = (
            (dataframe["close"] - bollinger["lowerband"]) /
            (bollinger["upperband"] - bollinger["lowerband"])
        )

        dataframe[f"%-roc-period_{period}"] = ta.ROC(dataframe, timeperiod=period)
        dataframe[f"%-atr_pct-period_{period}"] = (
            ta.ATR(dataframe, timeperiod=period) / dataframe["close"]
        )
        dataframe[f"%-mfi-period_{period}"] = ta.MFI(dataframe, timeperiod=period)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame,
                                         metadata: dict, **kwargs) -> DataFrame:
        dataframe["%-adx"] = ta.ADX(dataframe, timeperiod=14)

        macd = ta.MACD(dataframe)
        dataframe["%-macdhist_norm"] = macd["macdhist"] / dataframe["close"]

        dataframe["%-volume_ratio"] = (
            dataframe["volume"] / dataframe["volume"].rolling(20).mean()
        )
        dataframe["%-high_low_range"] = (
            dataframe["high"] - dataframe["low"]
        ) / dataframe["close"]

        ema10 = ta.EMA(dataframe, timeperiod=10)
        ema50 = ta.EMA(dataframe, timeperiod=50)
        ema200 = ta.EMA(dataframe, timeperiod=200)
        dataframe["%-ema_10_50_ratio"] = (ema10 - ema50) / ema50
        dataframe["%-ema_50_200_ratio"] = (ema50 - ema200) / ema200
        dataframe["%-ema_50_dist"] = (dataframe["close"] - ema50) / dataframe["close"]
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame,
                                     metadata: dict, **kwargs) -> DataFrame:
        # Long-lookback regime features on the base timeframe ONLY — putting
        # these in expand_basic would recompute them on 1h too, where a 672-
        # candle lookback needs 4 weeks of data and NaN-starves predictions.
        dataframe["%-roc_48h"] = dataframe["close"].pct_change(192)
        dataframe["%-roc_96h"] = dataframe["close"].pct_change(384)
        dataframe["%-roc_7d"] = dataframe["close"].pct_change(672)

        roll_max = dataframe["close"].rolling(self.ATR_PERIOD).max()
        roll_min = dataframe["close"].rolling(self.ATR_PERIOD).min()
        dataframe["%-donchian_pos_24h"] = (
            (dataframe["close"] - roll_min) / (roll_max - roll_min)
        )

        dataframe["%-day_of_week"] = dataframe["date"].dt.dayofweek
        dataframe["%-hour_of_day"] = dataframe["date"].dt.hour
        return dataframe

    # ── Triple-barrier target ─────────────────────────────────────────────────
    def set_freqai_targets(self, dataframe: DataFrame,
                           metadata: dict, **kwargs) -> DataFrame:
        H = self._label_candles()
        close = dataframe["close"].values
        high = dataframe["high"].values
        low = dataframe["low"].values
        atr_frac = ta.ATR(dataframe, timeperiod=self.ATR_PERIOD).values / close
        barrier = self.BARRIER_K * atr_frac

        n = len(dataframe)
        labels = np.full(n, np.nan, dtype=object)
        for i in range(n - H):
            b = barrier[i]
            if not np.isfinite(b):
                continue
            up_lvl = close[i] * (1 + b)
            dn_lvl = close[i] * (1 - b)
            w_hi = high[i + 1:i + 1 + H]
            w_lo = low[i + 1:i + 1 + H]
            hit_u = w_hi >= up_lvl
            hit_d = w_lo <= dn_lvl
            u = np.argmax(hit_u) if hit_u.any() else 10 ** 6
            d = np.argmax(hit_d) if hit_d.any() else 10 ** 6
            if u < d:
                labels[i] = "tb_up"
            elif d < u:
                labels[i] = "tb_down"
            else:
                labels[i] = "tb_flat"
        # Tail rows (future unknown) stay NaN → dropped from training.
        dataframe["&-tb_label"] = labels
        return dataframe

    # ── Indicators ────────────────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        dataframe = self.freqai.start(dataframe, metadata, self)

        # Barrier width at signal time — consumed by enter_tag / exits.
        dataframe["barrier_frac"] = (
            self.BARRIER_K
            * ta.ATR(dataframe, timeperiod=self.ATR_PERIOD)
            / dataframe["close"]
        )
        # Vol-regime ratio: current 24h ATR vs its 7-day median.
        dataframe["vol_regime"] = dataframe["barrier_frac"] / (
            dataframe["barrier_frac"].rolling(672).median()
        )
        return dataframe

    # ── Entries ───────────────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        p = self.prob_threshold.value
        m = self.prob_margin.value

        p_up = dataframe["tb_up"].iloc[-1]
        p_dn = dataframe["tb_down"].iloc[-1]
        do_predict = dataframe["do_predict"].iloc[-1]
        logger.info(
            f"🔎 {metadata['pair']} | P(up)={p_up:.2f} P(down)={p_dn:.2f} "
            f"do_predict={do_predict} | need p>{p} margin>{m}"
        )

        calm = dataframe["vol_regime"] < self.vol_regime_max.value
        long_cond = (
            (dataframe["do_predict"] == 1)
            & calm
            & (dataframe["tb_up"] > p)
            & ((dataframe["tb_up"] - dataframe["tb_down"]) > m)
            & (dataframe["volume"] > 0)
        )
        short_cond = (
            (dataframe["do_predict"] == 1)
            & calm
            & (dataframe["tb_down"] > p)
            & ((dataframe["tb_down"] - dataframe["tb_up"]) > m)
            & (dataframe["volume"] > 0)
        )
        dataframe.loc[long_cond, "enter_long"] = 1
        dataframe.loc[short_cond, "enter_short"] = 1
        dataframe.loc[long_cond | short_cond, "enter_tag"] = (
            dataframe["barrier_frac"].round(5).astype(str)
        )
        return dataframe

    # ── Exits (model flips) ───────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        p = self.exit_prob_threshold.value
        dataframe.loc[
            (dataframe["do_predict"] == 1) & (dataframe["tb_down"] > p),
            "exit_long",
        ] = 1
        dataframe.loc[
            (dataframe["do_predict"] == 1) & (dataframe["tb_up"] > p),
            "exit_short",
        ] = 1
        return dataframe

    # ── Post-loss cooldown ────────────────────────────────────────────────────
    def confirm_trade_exit(self, pair: str, trade: Trade, order_type: str,
                           amount: float, rate: float, time_in_force: str,
                           exit_reason: str, current_time: datetime,
                           **kwargs) -> bool:
        if exit_reason in (
            "stoploss", "stoploss_on_exchange", "trailing_stop_loss", "liquidation",
        ):
            hours = self.lock_hours.value
            if hours and hours > 0:
                self.lock_pair(
                    pair,
                    until=current_time + timedelta(hours=float(hours)),
                    reason=f"stoploss_cooldown_{hours}h",
                )
        else:
            hours = self.reentry_cooldown_hours.value
            if hours and hours > 0:
                self.lock_pair(
                    pair,
                    until=current_time + timedelta(hours=float(hours)),
                    reason=f"reentry_cooldown_{hours}h",
                )
        return True
