from TradingMLStrategyV2 import TradingMLStrategyV2


class TMLXK6(TradingMLStrategyV2):
    """
    X6 research variant (2026-07-14): 1.5x wider barriers on 15m (K=6 vs 4).

    Tests the fee-to-edge thesis at the 15m horizon directly: TP/SL at
    ±6×ATR(96) (~1.5-2% price, ~4.5-6% leveraged) cuts fee share per win by
    ~a third vs K=4. V3 tested 2x-wider at 1h and failed; this is the
    intermediate point on the same axis. Label and execution move together
    since both derive from BARRIER_K.
    """

    BARRIER_K = 6.0
